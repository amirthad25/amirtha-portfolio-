document.addEventListener('DOMContentLoaded', () => {
    // Navigation active state
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));
            // Add active class to clicked link
            e.target.classList.add('active');
        });
    });

    // Smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Check if video is loaded
    const video = document.getElementById('background-video');
    video.addEventListener('loadeddata', () => {
        document.body.classList.add('video-loaded');
    });

    // Fallback for video loading error
    video.addEventListener('error', () => {
        document.body.style.backgroundColor = '#1a1a1a';
    });

    // Scroll animations
    const observerOptions = {
        threshold: 0.2
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Add visible class to section title
                const title = entry.target.querySelector('.section-title');
                if (title) title.classList.add('visible');

                // Add visible class to content
                const content = entry.target.querySelector('.about-content, .projects-grid');
                if (content) {
                    content.classList.add('visible');
                }
            }
        });
    }, observerOptions);

    // Observe sections
    document.querySelectorAll('.about, .projects').forEach(section => {
        observer.observe(section);
    });

    // Update active navigation based on scroll position
    const sections = document.querySelectorAll('section[id]');
    
    window.addEventListener('scroll', () => {
        const scrollPosition = window.scrollY + window.innerHeight / 2;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    });
}); 